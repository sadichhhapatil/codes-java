package ipa.tcs;

import java.util.Scanner;
import ipa.tcs.Associate;
import java.util.Arrays;
public class AssoSolution{
    public static void main(String[] args){
    	 Associate[] associates = new Associate[5];
        Scanner sc = new Scanner(System.in);
       
        for(int i=0; i<5; i++){
            associates[i] = new Associate(sc.nextInt(), sc.next(),sc.next(), sc.nextInt());
            //sc.nextLine();
        }
         String search = sc.next();
         sc.close();
         Associate[] result = associatesForGivenTechnology(associates, search);
         for(int i=0; i<result.length; i++){
             System.out.println(result[i].getId());
         }
    }
    
    public static Associate[] associatesForGivenTechnology(Associate[] associates, String search){
         Associate[] help = new Associate[0];
        for(int i=0; i<associates.length; i++){
           
            if(associates[i].getTech().equalsIgnoreCase(search) && associates[i].getExInYears()% 5 ==0 ){
               help = Arrays.copyOf(help, help.length+1);
               help[help.length-1] = associates[i];
            }
            
        }
        return help;
    }
}

