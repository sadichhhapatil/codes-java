package ipa.tcs;

public class Medicine {
	String medicineName;
	String batch;
	String disease; 
	int price;
	
	public String getDisease() {
		return disease;
	}
	
	public int getPrice() {
		return price;
	}
	public Medicine(String medicineName, String batch, String disease, int price) {
		this.medicineName = medicineName;
		this.batch = batch;
		this.disease = disease;
		this.price = price;
	}


}
