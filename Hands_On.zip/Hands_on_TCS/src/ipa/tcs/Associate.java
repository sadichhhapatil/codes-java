package ipa.tcs;

public class Associate{
    int id;
    String name;
    String tech;
    int exInYears;
    
    public Associate(int id, String name, String tech, int exInYears){
        this.id = id;
        this.name = name;
        this.tech = tech;
        this.exInYears = exInYears;
    }
    public int getId(){
        return id;
    }
    public String getTech(){
        return tech;
    }
     public int getExInYears(){
        return exInYears;
    }
    
}