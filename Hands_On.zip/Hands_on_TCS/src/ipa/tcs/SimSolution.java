package ipa.tcs;

import java.util.Scanner;
import java.util.Arrays;
import ipa.tcs.Sim;

public class SimSolution {
	public static void main(String[] args) {
	    
		   Scanner sc = new Scanner(System.in);
		   Sim[] sim = new Sim[4];
		   for(int i=0; i<sim.length; i++){
		       sim[i] = new Sim(sc.nextInt(), sc.next(), sc.nextInt(), sc.nextDouble(), sc.next());
		   }
		    String sea_cir = sc.next();
		    double sea_rate = sc.nextDouble();
		   // sc.nextLine();
		    sc.close();
		     Sim[] result = matchAndSort(sim, sea_cir, sea_rate);
		     for(int i =0; i<result.length; i++){
		         System.out.println(result[i].getId());
		     }
		    
		}
		public static Sim[] matchAndSort(Sim[] sim, String sea_cir, double sea_rate){
		    Sim[] help = new Sim[0];
		    for(int i=0; i<sim.length; i++){
		    if((sim[i].getCir()).equals(sea_cir) && (sim[i].getRps() < sea_rate)){
		        help = Arrays.copyOf(help, help.length+1);
		        help[help.length-1] = sim[i];
		       }
		    }
		    return help;
		}

}
