package ipa.tcs;
public class Sim{
    int id;
	 String com;
    int bal;
	 double rps;
	 String cir;
	    
	 public Sim(int id, String com, int bal, double rps, String cir){
	     this.id = id;
	     this.com = com;
	     this.bal = bal;
	     this.rps = rps;
	     this.cir = cir;
	 }
	 public int getId(){
	     return id;
	 }
	 
	 public String getCir(){
	     return cir;
	 }
	 
	 public double getRps(){
	     return rps;
	 }
	 
	 public int getBal(){
	     return bal;
	 }
	 
}