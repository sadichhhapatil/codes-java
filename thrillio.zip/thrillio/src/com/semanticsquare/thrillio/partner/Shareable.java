package com.semanticsquare.thrillio.partner;

public interface Shareable {
	String getItemData();
	

}
