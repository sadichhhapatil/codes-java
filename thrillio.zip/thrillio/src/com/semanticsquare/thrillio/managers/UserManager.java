package com.semanticsquare.thrillio.managers;

import com.semanticsquare.thrillio.dao.UserDao;
import com.semanticsquare.thrillio.entities.User;

public class UserManager {
	/*
	 * instance is a private variable and created instance here. so to access from
	 * static method need to make variable static.
	 */

	private static UserManager instance = new UserManager();
	//invoking user dao
	private static UserDao dao = new UserDao();

	private UserManager() {
	}

	public static UserManager getInstance(){
		return instance;
	}

	// create a method instantiating user (class) this method is later invoked by datastore
	public User createUser(long id, String email, String password, String firstName, String lastName, 
			int gender, String userType) {
		User user = new User();
		user.setId(id);
		user.setEmail(email);
		user.setPassword(password);
		user.setFirstName(firstName);
		user.setLastName(lastName);
		user.setGender(gender);
		user.setUserType(userType);
		
		return user;
	}
	
	public User[] getUsers() {
		return dao.getUsers();
	}
}
