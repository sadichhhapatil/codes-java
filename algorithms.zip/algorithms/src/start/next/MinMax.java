package start.next;
import java.util.Scanner;

public class MinMax {
	static int min, max;
	
	static int maxx(int[] ar) {
		max = Integer.MIN_VALUE;
		for(int i = 0; i<ar.length; i++) {
			if(max < ar[i]) {
				max = ar[i];
			} 
			
		}
		return max;
	}
	
	static int minn(int[] ar) {
		
		min = Integer.MAX_VALUE;
		for(int i = 0; i<ar.length; i++) {
			if(min > ar[i]) {
				min = ar[i];
			}
		}
		return min;
	}
     
      
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("How many numbers you want to enter? : ");
		int n = sc.nextInt();
		
		int[] ar = new int[n];
		for(int i= 0; i<n; i++) {
			System.out.print("Enter the number : ");
			ar[i] = sc.nextInt();
		}
		
		min = minn(ar);
		max = maxx(ar);
		System.out.println("Min value in given array : " +min);
		System.out.println("Max value in given array : " +max);
		
		

	}

}
