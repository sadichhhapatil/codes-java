package start.next;

public class UnionANdIntersection {
    public static int unionAr(int[] arr1, int[] arr2, int n, int m) {
    	int i=0,j=0;
    	while(i < n && j < m) {
    		if(arr1[i] < arr2[j]) {
    			System.out.print(arr1[i++]+ " ");
    			
    		}else
    		if(arr2[j] < arr1[i]) {
    			System.out.print(arr2[j++]+" ");
    			
    		}
    		else 
    		if(arr1[i] == arr2[j]){
    			System.out.print(arr2[j++]+" ");
    			i++;
    		}
    	}
    	
    	while(i < n) {
    		System.out.print(arr1[i++]+" ");
    	
    	}
    	while(j < m) {
    		System.out.print(arr2[j++]+" ");
    		
    	}
    	System.out.println();
    	return 0;
    }
    
    public static void doIntersection(int[] arr1, int[] arr2, int n, int m) {
    	System.out.println("Duplicate Values");
    	for(int i=0; i<n; i++) {
    		for(int j=0; j<m; j++) {
    			if(arr1[i] == arr2[j]) {
    				System.out.println(arr2[j]+" ");
    			}
    		}
    	}
    	
    	
    }
	public static void main(String[] args) {
		int[] arr1 = {1, 3, 4, 5, 7};
        int[] arr2 = {2, 3, 5, 6};
        
        int n = arr1.length;
        int m = arr2.length;
        
        unionAr(arr1, arr2, n, m);
        doIntersection(arr1, arr2, n, m);

	}

}
