package start.next;
import java.util.Arrays;
import java.util.Scanner;

public class KthMInMax {
	
	static int[] revArr(int[] arr, int k) {
		for(int i =0; i<k/2; i++) {
			int temp = arr[i];
			arr[i] = arr[k-1];
			arr[k-1] = temp;
			
			k--;
		}
		return arr;
	}
	
	static int kthMinElement(int[] arr,int m) {
		int y = 0;
		for(int i=0; i<arr.length; i++) {
			
			if(m == i) {
				return arr[i];
			}
			
		}
		return 0;
		
	}
	
	static int kthMaxElement(int[] arr, int m) {
		int k = arr.length;
		int[] revAr = revArr(arr,k);
        for(int i=0; i<revAr.length; i++) {
			
			if(m == i) {
				return arr[i];
			}
			
		}
		return 0;
		
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("how many no's you want? : ");
		int n = sc.nextInt();
		int[] arr = new int[n];
		
		for(int i=0; i<n; i++) {
			arr[i] = sc.nextInt();
		}
		
		Arrays.sort(arr);
		
//		for(int i : arr) {
//			System.out.println(i);
//		}
		
		int x = kthMinElement(arr,0);
		System.out.println(x);
		
		int y = kthMaxElement(arr,1);
		System.out.println(y);

	}

	

}
