package start.next;

public class RevArr {
	static int[] revArr(int[] a, int n) {
		for(int i =0; i<n/2; i++) {
			int temp = a[i];
			a[i] = a[n-1];
			a[n-1] = temp;
			
			n--;
		}
		return a;
	}
	
	public static void main(String[] args) {
		int[] a = {1,2,3,4,5,6,7,8};
		int n = a.length;
		
		int[] res = revArr(a,n);
		
		for(int i=0; i<res.length; i++) {
			System.out.print(res[i]+" ");
			
		}
		
	}

}
