package start.next;

import java.util.Scanner;

public class RverseString {
	public static String[] longestCommonPrefix(String[] ar) {
		int j = ar.length-1;
		for(int i= 0; i<ar.length/2; i++) {

			String temp = ar[i];
			ar[i] = ar[j];
			ar[j] = temp;
			j--;
		}
		return ar;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s = sc.next();
		String[] ar = new String[s.length()];
		for(int i= 0; i<s.length(); i++) {
			ar[i] = s.substring(i,i+1);
		}
		
		String[] m = longestCommonPrefix(ar);
		String n = "";
		
		for(String i : m) {
			n +=i;
		}
		System.out.println(n);
		
		if(s.equals(n)) {
			System.out.println("Name is Palindrome");
		}else
		{
			System.out.println("not");
        }

	}
}
