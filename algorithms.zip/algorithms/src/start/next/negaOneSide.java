package start.next;

public class negaOneSide {
	
	public static int[] shiftAllNegativeOneSide(int[] a, int n) {
		int j = n-1;
	    for (int i = 0; i < n; i++) {
			   if (a[i] > 0) {
				   if(a[j] < 0) {
					   if(i != j) {
					   int temp = a[i];
					   a[i] = a[j];
					   a[j]= temp;
					  }
					   j--;
				}
				   
			  }
		}
	    return a;
	}

	public static void main(String[] args) {
		int[] a = {-12, 11, -13, -5, 6, -7, 5, -3, -6};
		int n = a.length;
		int[] sm = shiftAllNegativeOneSide(a,n);
		for(int i : sm) {
			System.out.println(i);
		}

	}

}
