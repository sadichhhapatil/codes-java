package start.next;
import java.util.Scanner;

public class DuplicateChar {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s = sc.next();
		String[] st = new String[s.length()];
		
		for(int i=0; i<s.length();i++) {
			st[i] = s.substring(i,i+1);
		}
		System.out.println(st.length);
		x : for(int i=0; i<st.length; i++) {
			int count = 1;
			
			for(int j= i+1; j<st.length; j++) {
				
				if(st[i].equals(st[j])) {
					count += 1;
				}
				if(st[i].equals(st[j])) {
					j+=1;
				}
				if(count>1) {
				    System.out.println(st[i]+" "+ count);
				    continue x;
				}
			}
			
		}
		
	}

}
