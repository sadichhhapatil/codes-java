package start.next;
import java.util.Arrays;
import java.util.Scanner;

public class LongestCommonPrefix {
	
    public static void main(String[] args) {
    	
    	
	}

}
