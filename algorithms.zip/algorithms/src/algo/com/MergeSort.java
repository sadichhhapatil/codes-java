package algo.com;

import java.util.Arrays;

public class MergeSort {
	 
	static void mergeValues(int[] a, int mid, int low, int high) {
		int i, j, k;
		int[] b = new int[high+1];
		i = low; j= mid+1; k=low;
	    while(i<=mid && j<=high) 
	    {
	      if(a[i]< a[j]) {
			b[k] = a[i];
		    i++;
		}
		else {
			b[k] = a[j];
		  j++;
		}
		k++;
	   }
		
	    while(i<=mid) {
			b[k] = a[i];
			k++; 
			i++;
		}
		
		while(j<=high) {
			b[k] = a[j];
			k++;
			j++;
		}
		
		for( i=low; i<=high; i++) {
			a[i] = b[i];
		}
	}
	
	static void recursiveMergeSort(int[] a, int low, int high) {
		int mid;
		if(low < high) {
			 mid = (low + high)/2;
		
	     	recursiveMergeSort(a, low, mid);
		
		    recursiveMergeSort(a, mid+1, high);
		
	    	mergeValues(a, mid, low, high);
		}
		
	}
		
	
	static void printArray(int[] a) {
		int n = a.length; 
		for(int i=0; i<=n-1; i++) {
			System.out.print(a[i]+" ");
			
		}
		System.out.println();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = {7,9,3,1,4,-1, 8};
		int n =7;
		System.out.println("Given Array");
		printArray(a);

       // MergeSort ob = new MergeSort();
        recursiveMergeSort(a, 0, 6);
        
		System.out.println("Sorted Array");
		printArray(a);
		}
}
