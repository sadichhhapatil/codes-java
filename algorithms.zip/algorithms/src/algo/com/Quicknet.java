//package algo.com;
//
//public class Quicknet {
//	//pseudocode for quick sort main algorithm
//	procedure quickSort(arr[], low, high)
//	    arr = list to be sorted
//	    low � first element of the array
//	    high � last element of array
//	begin
//	    if (low < high)
//	    {
//	       // pivot � pivot element around which array will be partitioned 
//	        pivot = partition(arr, low, high);
//	        quickSort(arr, low, pivot - 1);  // call quicksort recursively to sort sub array before pivot
//	        quickSort(arr, pivot + 1, high); // call quicksort recursively to sort sub array after pivot
//	    }
//	end procedure
//	 
//	//partition routine selects and places the pivot element into its proper position that will partition the array. 
//	//Here, the pivot selected is the last element of the array
//	procedure partition (arr[], low, high)
//	begin
//	    // pivot (Element to be placed at right position)
//	    pivot = arr[high];  
//	     i = (low - 1)  // Index of smaller element
//	    for j = low to high
//	    {
//	        if (arr[j] <= pivot)
//	        {
//	            i++;    // increment index of smaller element
//	            swap arr[i] and arr[j]
//	        }
//	    }
//	    swap arr[i + 1] and arr[high])
//	    return (i + 1)
//	
//
//}
