package algo.com;

import java.util.Arrays;

public class Quick_Sort {

	static void printArray(int[] a, int n) {
		
			System.out.print(Arrays.toString(a));
		
		System.out.println();
	}

	
	public static int partition(int[] a, int low, int high) {
		int pivot = a[low];
		int i = low;
		int j = high;
		int  temp;

     if(i <= j) {
			while (a[i] <= pivot) {
				i++;
			}
			while (a[j] > pivot) {
				j--;
			}
			while (i <= j) {
			    temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
     }

	    temp = a[low];
		a[low] = a[j];
		a[j] = temp;

		return j;
	}
	

	public static void quickSort(int[] a, int low, int high) {
		int loc;
		
		if (low < high) {
			loc = partition(a, low, high);
			quickSort(a, low, loc-1);
		
			quickSort(a, loc + 1, high);
			}
		}


	public static void main(String[] args) {
		int a[] = { 8, 4, 2, 10, 6, 5, 3, 7, 9, 2 };
		int n = 10;
		//Quick_Sort qs = new Quick_Sort();
		printArray(a, n);
		quickSort(a, 0, n-1);
		System.out.println("Sorted array");
		printArray(a, n);

	}

}
