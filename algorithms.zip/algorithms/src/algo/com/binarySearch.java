package algo.com;

public class binarySearch {
	
	public static int binarysSearch(int[] arr, int l, int h, int key) {
		if(l == h) {
			if(key == arr[l]) {
				return l;
			}
			else {
				return -1;
			}
		}
		int mid = (l+h)/2;
		if(key == arr[mid]) {
			return mid;
		}
		else
		if(key>arr[mid]){
			return binarysSearch(arr, mid+1, h,key);
		}
		else 
			return binarysSearch(arr, l, mid-1, key );
		
		
	}

	public static void main(String[] args) {
		int[] arr = {11,22,33,44,55,66,77,88,99};
		int key = 99;
		int index = binarysSearch(arr,0,8,key);
		if(index == -1) {
			System.out.println(" key is not present");
		}
		else {
		System.out.println(key + " is at index "+index);
		}
		
		

	}

}
