package apna.college.ds;

public class AddXtoEnd { 
	
	public static void addXToEnd(String st, int idx, int count, String s) {
		
		if(idx == st.length()) {
			for(int i=0; i< count; i++) {
				s += 'x'; 
			}
			System.out.println(s);
			return;
		}
		if(st.charAt(idx) == 'x') {
			count++;
			addXToEnd(st, idx+1, count, s); 
		}else { 			
			s += st.charAt(idx);
			addXToEnd(st, idx+1, count, s);  
		}
		//addXToEnd(st, idx+1, count);  
	}

	public static void main(String[] args) {
		String st = "axbcxxxxd";
		int count = 0;
		addXToEnd(st, 0, 0, "");

	}

}
