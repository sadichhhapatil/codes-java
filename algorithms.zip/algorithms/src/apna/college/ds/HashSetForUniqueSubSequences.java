package apna.college.ds;

import java.util.HashSet;

public class HashSetForUniqueSubSequences {
    public static void hashSetSubSequences(String str, int idx, 
			String newString, HashSet<String> set) {
		if(idx == str.length()) {
			if(set.contains(newString)) {
				return; 
			}else {
				System.out.println(newString); 
				set.add(newString); 
				return;
			}
			
		}
		char currChar = str.charAt(idx);
		
		//to be
		hashSetSubSequences(str, idx+1, newString+currChar, set);
		//System.out.println(newString);
		
		//not to be
		hashSetSubSequences(str, idx+1, newString, set);
		//System.out.println(newString);
	}
	public static void main(String[] args) {
		String str = "aaa";
		HashSet<String> set = new HashSet<>();
		hashSetSubSequences(str, 0, "", set);
	}

}
