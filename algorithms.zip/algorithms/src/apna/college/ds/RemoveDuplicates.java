package apna.college.ds;

public class RemoveDuplicates { 
	public static boolean[] map = new boolean[26];
	
	public static void removeDuplicates(String str, int idx, String newString) {
		if(idx == str.length()) {
			System.out.println(newString);
			return;
		}
		 
		char currtChar = str.charAt(idx);
		if(map[currtChar - 'a'] == true) {
			removeDuplicates(str, idx+1, newString);
		}else {
			newString += currtChar;  
			map[currtChar - 'a'] = true;
			removeDuplicates(str, idx+1, newString);
		}
	}

	public static void main(String[] args) {
		String str = "abbccdaxzzzz";
		removeDuplicates(str, 0, "");

	}
 
}
