package apna.college.ds;
import java.util.ArrayList;
import java.util.Collections;

public class ArrayListDemo {

	public static void main(String[] args) {
	    ArrayList<Integer> list = new ArrayList<>();
	    //add elements
	    list.add(10);
	    list.add(20);
	    list.add(30);
	    System.out.println(list);
	    
	    //get element
	    int ele = list.get(2);
	    System.out.println(ele);
	    
	    //to add element in between
	    list.add(1,40);
	    System.out.println(list);
	    
	    //set element
	    list.set(0, 5);
	    System.out.println(list);
	    
	    //remove ele
	    list.remove(3);
	    System.out.println(list);
	    
	    int size = list.size();
	    System.out.println(size);
	    
	    for(int i=0; i<list.size(); i++) {
	    	System.out.println(list.get(i));
	    }
	     
	    Collections.sort(list);
	    System.out.println(list);
	    
//	    list.clear(); 
//	    System.out.println(list);
	    
	    for(int i : list) {
	    	System.out.println(i);
	    }

	}

}
