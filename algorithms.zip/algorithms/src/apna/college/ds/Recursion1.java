package apna.college.ds;

//print x^n (stack height=n) 
//here n=5 bu calcPower function called 6 times
public class Recursion1 {
//	public static int calcPower(int x, int n) {
//		if(n==0) {
//			return 1; 
//		}
//		if(x==0) {
//			return 0;
//		}
//		int xPownm = calcPower(x,n-1);
//		int xpow = x*xPownm;
//		return xpow;
//	} 
	
	//print x^n --stack height = logn
	public static int calcPower(int x, int n) {
		if(n==0) {
			return 1;
		}
		if( x==0 ) {
			return 0;
		}
		if(n%2==0) {
			return calcPower(x, n/2) * calcPower(x, n/2);
		}
		else {
			return calcPower(x, n/2) * calcPower(x, n/2) * x;
		}
	}

	public static void main(String[] args) {
		int x=2, n=5;
		int ans = calcPower(x,n);
		System.out.println(ans);

	}

}
