package apna.college.ds;

public class RecursionStr {
	public static int first = -1; 
	public static int last = -1;
	public static void printOccurance(String sm , int n, char s) {
		if(n == sm.length()) {
			System.out.println(first+" "+last);
			return; 
		}
		if(sm.charAt(n) == s) { 
			if(first == -1) {  
				first = n;
			}else { 
				last = n; 
			}
		}
		printOccurance(sm, n+1, s);
		
	}
	//reverse the string using recursion
//	public static void reverseString(String s, int n) {
//		if(n == 0) {
//			System.out.print(s.charAt(n)); 
//			return;
//		}
//		 
//		System.out.print(s.charAt(n));
//		reverseString(s,n-1); 
//	}

	public static void main(String[] args) {
		//find the first and last occurance of an element in string
		
		 String sm = "bcdaaefghaana";
		 char s = 'a';
		 int n = 0; 
		 printOccurance(sm, n, s); 
		
		
		//string reverse
//		String s = "nitinm";
//		int n = s.length();
//		reverseString(s,n-1);
		
		
		

	}

}
