package apna.college.ds;

//print all the subsequences of a string--here choic is given to every character
//if they want to come or not...then we make subsequences..
public class StrSubSequences {

	public static void subsequences(String str, int idx, String newString) {
		if(idx == str.length()) {
			System.out.println(newString); 
			return;
		}
		char currChar = str.charAt(idx);
		 
		//to be
		subsequences(str, idx+1, newString+currChar);
		//System.out.println(newString);
		
		//not to be
		subsequences(str, idx+1, newString);
		//System.out.println(newString);
	}
	public static void main(String[] args) {
		String str = "aaa";
		subsequences(str, 0, "");

	}

}
