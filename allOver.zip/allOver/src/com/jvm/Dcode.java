package com.jvm;

import java.io.IOException;
import java.util.Scanner;

public class Dcode extends Decode {
	
	public void mixing(int m, int n){

		//super.mixing( m , n);
		System.out.println("In Dcode class");
		
		try {
			int k = m/n;
			}catch(ArithmeticException e) {
			System.out.println("any number can not divided by zero");
		}
}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Decode o = new Dcode();
		int m = sc.nextInt();
		int n = sc.nextInt();
		o.mixing(m,n);

	}

}
