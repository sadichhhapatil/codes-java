package com.jvm;
import java.io.IOException;
import java.util.Scanner;

public class Decode {
	public void mixing(int m, int n) {
		try {
			int k = m/n; 
			}catch(ArithmeticException e) {
			System.out.println("any number can not divided by zero");
		    }
		
		
	}
 
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Decode ob = new Decode();
		int m = sc.nextInt();
		int n = sc.nextInt();
		ob.mixing(m,n);
	} 
}
