package allOver;
public class BasicBasics {
	private int x;
	 BasicBasics(int x){
		 this.x = x;
		 System.out.println("i am in super class "+x);
				 
	 }
	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	
}
