package allOver;

public class Start {
    
	static void arrays() {
	int[] arr = new int[] {1,2,3,4};
	int[][] scores = new int[][] {
		{1,2},
		{2,3},
		{4,5},
		{6,7}
	};
	for(int i = 0; i< 4; i++) {
		for(int j = 0; j < 2; j++) {
	    System.out.print(scores[i][j]+" "); 
	    }
		System.out.println();
	  }
	
	for(int i[] : scores) {
		for(int j : i) {
		
			System.out.print(j+" ");
			}
		System.out.println();
	}
	
	for(int i = 0; i< arr.length; i++) {
		for(int j = 0; j< arr.length; j++) {
	    System.out.print("(" + arr[i]+", "+ arr[j]+")"); 
	    }
		System.out.println();
	  }
	

	}
	
	
	public static void main(String[] args) {
	   arrays();
	   
	}

}
