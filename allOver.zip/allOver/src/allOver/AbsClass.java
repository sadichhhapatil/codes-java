package allOver;

abstract class Parent2{
	
	abstract public void greeting();
}
 class Child2 extends Parent2{
	public void greeting(){
		
	System.out.println(" in child class ...");}
}
public class AbsClass {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child2 c = new Child2();
		c.greeting();
	}
}
