package allOver;

public class sparse {
	public static void main(String[] args) {
		//int i = 2;
		Integer j = Integer.valueOf("2");
		System.out.println(j);
		
		int k = j.intValue();
		System.out.println(k);
		

		Integer o = Integer.valueOf("678");
		System.out.println("object "+o);
		
		int g = o.intValue();
		System.out.println(g);
		
		//parsing strings
		String data = "1000 sadichha t 5.6";
		String[] item = data.split("\s");
		long id = Long.parseLong(item[0]);
		String title = item[1];
		char gen = item[2].charAt(0);
		double gpa = Double.parseDouble(item[3]);
		
		System.out.println(id);
		System.out.println(title);
		System.out.println(gen);
		System.out.println(gpa);
		
		//utilities(Boolean conditions method) methods foe char
		Boolean x = Character.isLetter(gen);
		Boolean y = Character.isUpperCase(gen);
		System.out.println(x);
		System.out.println(y);
		
		Boolean no = Double.isNaN(0.0/0.0);
		System.out.println(no);
		
		String b = Integer.toBinaryString(8);
		System.out.println(b);
		
	}

}
