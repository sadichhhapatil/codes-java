package allOver;
class A{
	public int a;
	public int harry(){ 
		return 4;
	}
	public void meth() {
		System.out.println(" i am in method 2...");
	}
}
class B extends A{
	@Override
	public void meth() {
		System.out.println(" i am in method 2 of class b...");
	}
	
}
public class method_overriding {

	public static void main(String[] args) {
		// TODO Auto-generated method st
		
		B a = new B();
		a.meth();
	}

}
