package allOver;

public class Circle extends BasicBasics {
	int y;
	Circle(int x , int y){
		super(x);
		this.y = y;
		
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 * BasicBasics one = new BasicBasics(); one.setX(49);
		 * System.out.println(one.getX());
		 */
		
		Circle o = new Circle(60, 30);
		
		Object obj = new StringBuilder("its me");
		Class a = obj.getClass();
		System.out.println(a.getName());
			
		System.out.println("foo".getClass());
		
		Class clazz = Void.class;
		System.out.println(clazz.getName());
		
		//o.setX(60);
		//o.setY(6444);
		//System.out.println(o.getX()+"  "+o.getY());
		System.out.println(o.getX()+" "+o.y);

	}
}
