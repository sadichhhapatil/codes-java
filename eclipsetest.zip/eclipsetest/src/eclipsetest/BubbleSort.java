package eclipsetest;

import java.util.Scanner;

public class BubbleSort {
	
	   int[] bubbleSort(int arr[])
	      {
	          int len = arr.length; // calculating the length of array
	          for (int i = 0; i < len-1; i++) {
	            for (int j = 0; j < len-i-1; j++) if (arr[j] > arr[j+1]) //comparing the pair of elements
	               {
	                 // swaping a[j+1] and a[i]
	                   int temp = arr[j];
	                   arr[j] = arr[j+1];
	                   arr[j+1] = temp;
	                }}
			/*
			 * for (int i=0; i<len; i++) { //System.out.print(a[i] + " "); //printing the
			 * sorted array // System.out.println(); ret }
			 */
	          return arr;
	        }

	    
	        public static void main(String args[])
	            {
	                BubbleSort ob = new BubbleSort();
	                Scanner sc = new Scanner(System.in);
	                System.out.println("Enter the no of elements : ");
	                int n = sc.nextInt();
	                int[] arr = new int[n];
	                for (int i=0; i<n; i++) {
						arr[i] = sc.nextInt();
					}
	                //int arr[] = {64, 34, 25, 12, 22, 11, 90};
	                System.out.println("Sorted array");
	               // ob.printArray(a); //calling the printArray function
	                int[] newArray = ob.bubbleSort(arr);
	                for(int i : newArray) {
	                	System.out.print(i+" ");
	                }
	             }
	}


