package eclipsetest;
import java.lang.Math;
public class Box{
	/*double width = 20;
	double height = 10;
	double depth = 5;*/
	//double random = Math.random();
	private static int no = 1000;
	private final int id;
	private static int idInitializer = 1000;
	private final int id1;
	{
		System.out.println("In the initializer block....");
	}
	{
		id1 = ++idInitializer;
		System.out.println("id1 :"+id1);
		
	}
	private static void mathDemo() {
	double random = Math.random();
	int winner = (int)(random*100);
	System.out.println(random);
	System.out.println("winner "+winner);
	
	int d = Math.round(4.87f);
	System.out.println("d "+d);
	
      double m = Math.ceil(4.567);
      System.out.println(m);
      
      double o = Math.floor(4.897);
      System.out.println(o);
      
      int b= Math.max(69, 56);
      System.out.println(b);
      
     double r = Math.pow(5.0, 2.0);
     System.out.println(r);
     
      double t =  Math.cbrt(8);
      System.out.println(t);
	}
	Box(){
		id = ++no;
		System.out.println(id);
	}
	
	double volumeCom(int width, int height, int depth){
		System.out.println("In the constructor....");
		System.out.println(no);
		
	    return width * height * depth;
	 
	}

	double avg(int width, int height, int depth){
		double volumes = volumeCom(width, height,depth);
	 return volumes/3;
	}
	
	public static void main(String[] args){
	    Box b = new Box();
	    double vol = b.volumeCom(20,10,5);

	    System.out.println("volume: " +vol);

	    vol = b.avg(30,45,5);
	   System.out.println(vol);
	   mathDemo();


}




} 