package eclipsetest;

public interface Test {
	private void test() {}
}
