package eclipsetest;

public class HelloWorld {
	int id = 67;

	public static void main(String[] args) {

		// TODO Auto-generated method stub System.out.println("Hello!!");

		long l = 40;
		int i = (int) l;
		System.out.println(i);
	}

}
