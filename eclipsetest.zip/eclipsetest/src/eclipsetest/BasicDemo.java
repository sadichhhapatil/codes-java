package eclipsetest;
import java.util.*;

import com.sun.jdi.Method;

import java.math.BigDecimal;

class BasicDemo{
	byte num = 127; //-128 to 127
	short map = 32767; //-32768 to 32767
	char wish = 65;

	char mis = 'z';
	int cash = 60000;
	long pno = 99_21_43_51;

        int j = (int)pno;
	float gpa = 5.60f;
	double kpa = 6.87245478;
	boolean wax;
  
	BigDecimal one = new BigDecimal("0.123");
	BigDecimal two = new BigDecimal("0.67");
	
	static int[] arr = {1,2,3,4};


 	 void printValues(){
		//int sim = 45;
		if(wax == false){
                int sim = 4;
		System.out.println("sim : " +sim);	
	}
	
		
		System.out.println("num : " +num);
		System.out.println("map : " +map);
		System.out.println("wish : " +wish);
		System.out.println("mis : " +(int)mis);
		System.out.println("cash : " +cash);
		System.out.println("pno : " +pno);
		System.out.println("j : " +j);
		System.out.println("gpa : " +gpa);
		System.out.println("kpa : " +kpa);
		System.out.println("bd : " + one.add(two) );
} 
	static void arrays(){
	    for(int i : arr){
	        System.out.print("\n"+i);
	}

	}

	public static void main(String[] args){
		BasicDemo s = new BasicDemo();
		s.printValues();
		arrays();
		//printValues();
}
}