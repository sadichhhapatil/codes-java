package com.semanticsquare.io;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class DemoOfIO {
	static String infile = "Vasco.txt"; 
	static String outfile = "VascoOut.txt";
    public static void fileCopy() {
    	long startTime = 0, elapsedTime;
    	System.out.println("file copy");
    	try(FileInputStream in = new FileInputStream(infile);
    			FileOutputStream out = new FileOutputStream(outfile)){
    		int byteRead;
    		while((byteRead = in.read()) != -1) {
    			out.write(byteRead);
    		}
    		elapsedTime = System.nanoTime() - startTime;
			System.out.println("Elapsed Time is " + (elapsedTime / 1000000.0) + " msec");
    		 
    	}catch (IOException e) { 
			e.printStackTrace();
		} 
    }
    
    public static void fileCopyWithBufferAndArray() {
		System.out.println("\nInside fileCopyWithBufferAndArray ...");
		
		long startTime, elapsedTime; // for speed benchmarking
		startTime = System.nanoTime();
		try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(infile));
				BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(outfile))) {

			byte[] byteBuf = new byte[4000];
			int numBytesRead;
			while ((numBytesRead = in.read(byteBuf)) != -1) {
				out.write(byteBuf, 0, numBytesRead);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		elapsedTime = System.nanoTime() - startTime;
		System.out.println("fileCopyWithBufferAndArray: " + (elapsedTime / 1000000.0) + " msec");
	}
 
	public static void main(String[] args) {
		fileCopy();
		fileCopyWithBufferAndArray();

	}

}
