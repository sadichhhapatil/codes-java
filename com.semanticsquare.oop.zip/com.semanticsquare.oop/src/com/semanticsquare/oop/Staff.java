package com.semanticsquare.oop;

public class Staff extends User {
	  public int id= 3;
//	  
//	  public Staff() {
//		  userType = "staff";
//		  System.out.println("Staff Constructor1");
//	  }
	  public Staff(int id) {
		 // this();
		 super(id);
		  this.id = id;
		  System.out.println("Staff Constructor2");
	  }
	  public void printId(){
		System.out.println("id "+id);
		System.out.println("super.id "+super.id);
	}
	   public void printUserType() {  
		   System.out.println("Staff");
	   
	  } 
	   public Review postAReview(String reviewText) {
	  System.out.println("Staff : postAReview"); 
	  Review review = super.postAReview(reviewText);
	  review.setApproved(true);
	  return review;
	} 
	   public void instanceMethod(int d) {
			System.out.println("staff : instancemethod");
		}
	   
	   public static void staticMethod() {
			 System.out.println("Staff : staticMethod");
		 }
	

}
