package com.semanticsquare.oop;

public class Editor extends Staff {
	
	  public Editor(int id) {
		super(id);
		// TODO Auto-generated constructor stub
	}

	public void printUserType() {
		  System.out.println("Editor"); 
	  }
	 
	public void approveReview() {
		System.out.println("Editor : approveReview");
	}

}
