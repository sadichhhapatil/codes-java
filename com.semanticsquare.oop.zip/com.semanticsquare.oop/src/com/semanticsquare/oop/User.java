package com.semanticsquare.oop;

public class User {
	    public int id = 4;
		//public String id;
	    public String userType = "User";
	  
	    public User(int id) {
	    	System.out.println("User constructor");
	    }
		public void printUserType(){
			System.out.println("User");
		}
		
		public void saveWebLink() {
			System.out.println("User: saveWebLink");
			postAReview("");
			staticMethod();
		}
		
		public Review postAReview(String reviewText) {
			System.out.println("User: postAReview");
			Review review = new Review(reviewText);
			return review;
		}
		
		 public void instanceMethod(double d) {
			System.out.println("user : instancemethod");
		}
		 public static void staticMethod() {
			 System.out.println("User : staticMethod");
		 }

		public void displayUserInfo() {
			// TODO Auto-generated method stub
			System.out.println(this);
		}
		
		public String toString() {
			return "id: "+id+"\n userType "+userType;
		}

}
