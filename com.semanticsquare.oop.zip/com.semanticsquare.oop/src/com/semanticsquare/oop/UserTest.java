package com.semanticsquare.oop;

public class UserTest {
	public void printUserType(User u) {
		u.printUserType();
	}

	public void approveReview(Staff s) {
		// s.approveReview();
		if (s instanceof Editor) {
			((Editor) s).approveReview();
		} else {
			System.out.println("Invalid object is passed");
		}
	}

	public static void main(String[] args) {

		// TODO Auto-generated method stub
		// objects of each class is created by using supertype as a reference

		//User user = new User();
		//User staff = new Staff();
		//User staff = new Editor();
		
		//staff.instanceMethod(10);
		//staff.staticMethod();
		//((Staff)staff).staticMethod();
		//staff.saveWebLink();
		//staff.postAReview("");
		
		//((Staff)staff).printId();
		/*
		 * //User object is assigned to ref.variable of type User
//		 * 
		 * User user = new User();
		 * 
		 * //Staff object is assigned to ref.variable of type User User staff = new
		 * Staff(); User editor = new Editor();
		 * 
		 * UserTest ut = new UserTest();
		 * 
		 * ut.printUserType(user); ut.printUserType(staff); ut.printUserType(editor);
		 * 
		 * //part2 //editor.approveReview(); //editor.postAReview();
		 * editor.saveWebLink(); Staff net = new Editor(); ut.approveReview(net);
		 * ut.approveReview(new Staff());
		 */
		
		//Object class -> core methods
		//User staff = new Staff();
		//staff.displayUserInfo();
		//System.out.println(staff.toString());
		
		//hashcode
//		User staff = new Staff();
//		User staff2 = staff;
//		System.out.println(staff2.hashCode());
//		System.out.println(staff.hashCode());
		
		User staff = new Staff(7);
	}

}
