package com.semanticsquare.exceptions.assertions;

public class B {

	void test(int i) {
		assert i > 0 : "invalid i in B.test";
	}
	
}
