package HMS;

public class SilverPlan extends HealthInsurancePlan {
	public SilverPlan() {
		this.coverage = 0.7;
	}

}
