package HMS;


	class PlatinumPlan extends HealthInsurancePlan{
	    
	    
		public PlatinumPlan() {
			
			this.coverage = 0.9;
		}
		//HealthInsurancePlan cov = new PlatinumPlan();
	   
	}


