package HMS;

public class BronzePlan extends HealthInsurancePlan {
	 public BronzePlan() {
		this.coverage = 0.6;
	}

}
