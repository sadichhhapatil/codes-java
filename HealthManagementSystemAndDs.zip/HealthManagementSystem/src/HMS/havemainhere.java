package HMS;

public class havemainhere {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HealthInsurancePlan insurancePlan = new PlatinumPlan();
		Patient patient = new Patient();
		patient.setInsurancePlan(insurancePlan);
		
		double[] payments = Billing.computePaymentAmount(patient, 1000);
		System.out.println(payments[0]+" "+payments[1]);

	}

}
