package HMS;

public class GoldPlan extends HealthInsurancePlan {
	public GoldPlan() {
		this.coverage = 0.8;
	}

}
