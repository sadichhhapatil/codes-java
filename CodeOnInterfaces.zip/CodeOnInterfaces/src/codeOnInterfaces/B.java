package codeOnInterfaces;

public interface B {
	int VAL = TestClient.getVal();
	void foo();
//	default void go() {
//		System.out.println("B : go");
//	}

}
