package codeOnInterfaces;

public class TestClient {
	public static int getVal() {
		return 76;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		A a = new X();
//		a.foo();
//		a.bar();
//		((X) a).fooBar();
		C c = new X();
//		C clone =  ((X)c).clone();
//		if(clone != c) {
//			System.out.println("Clone Created");
//		}
		//default method demo
		c.go();
		
	}

}
