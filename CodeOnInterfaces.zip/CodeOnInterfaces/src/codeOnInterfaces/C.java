package codeOnInterfaces;

public interface C extends A{
	void fooBar();
	default void go() {
		System.out.println("C : go");
	}

}
