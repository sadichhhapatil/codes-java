package codeOnInterfaces;

public abstract class AbstractA implements A{
	public void bar() {
		System.out.println("AbstractA : bar");
	}
	
}
